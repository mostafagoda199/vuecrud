<?php

namespace App\Console\Commands;
use App\Console\Commands\Helper\AddHelper;
use App\Console\Commands\Helper\AddInterface;
use App\Console\Commands\Helper\AddProvider;
use App\Console\Commands\Helper\AddRepository;
use App\Console\Commands\Helper\AddRoute;
use App\Console\Commands\Helper\AddView;
use App\Console\Commands\Helper\CreateController;
use App\Console\Commands\Helper\traits\MoveModel;
use App\Console\Commands\Helper\traits\CreateFolder;
use Illuminate\Console\Command;
class CustomCommand extends Command
{
    use CreateFolder,MoveModel;
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'create:module {moduleName}';
    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Create Strucure Of Module';
    /**
     * Create a new command instance.
     *
     * @return void
     */
    protected $med;
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        /** Array Of Folder In Array */
        $moduleContaint=['Controllers','Interfaces','Models','Providers','Repository','Route','views'];
        /** Folder Module*/
        static::_createFolder('app','',['Modules','General']);
        /** Folder In General */
        static::_createFolder('app','General',['Helper','Interface','Repository']);
        /** Module Name */
        $med=ucfirst($this->argument("moduleName"));

        /** Folder Containt in Module*/
        static::_createFolder('app/Modules',$med,$moduleContaint);
        /** Controller */
        CreateController::_createController($med);
        /** Model */
        $this->_moveModels($med);
        /** Interface */
        AddInterface::_contentInterface($med);
        /** Repository */
        AddRepository::_contentRepository($med);
        /** Views */
        AddView::_contentView($med,['add','edit','index','show']);
        /** Route */
        AddRoute::_contentRoute($med);
        AddRoute::_editRoute($med);
        AddHelper::_contentHelper();
        AddInterface::_contentCrudInterface();
        AddRepository::_contentCrudRepository();
        /** Edit Provider */
        AddProvider::_editProvider($med);
    }
}
