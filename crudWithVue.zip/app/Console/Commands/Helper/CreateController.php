<?php
/**
 * Created by PhpStorm.
 * User: Mustafa
 * Date: 7/26/2019
 * Time: 1:13 AM
 */

namespace App\Console\Commands\Helper;


use Illuminate\Support\Facades\Artisan;

class CreateController
{
    public static function _createController($med)
    {
        Artisan::call('make:controller',['name'=> '../../Modules/'.$med.'/controllers/'.$med.'Controller' ,'-r'=>true]);
        $controllerPath='app/Modules/'.$med.'/controllers/'.$med.'Controller.php';
        $current = file_get_contents($controllerPath);
        $newController=str_replace('\Http\Controllers\..\..','',$current);
        file_put_contents($controllerPath, $newController);
        echo "Controller ".$med."Controller Created successfully"."\n";
    }
}