<?php
/**
 * Created by PhpStorm.
 * User: Mustafa
 * Date: 7/26/2019
 * Time: 12:12 AM
 */

namespace App\Console\Commands\Helper;


use App\Console\Commands\Helper\traits\AddComment;
use App\Console\Commands\Helper\traits\CreateFile;

class AddInterface
{
    use CreateFile ,AddComment;

    public static function _contentInterface($med)
    {
        $contentInterface= '<?php             
        '.self::_comment().'
        namespace App\Modules\\'.$med.'\Interfaces; 
        interface '.$med.'RepositoryInterface{
        //
        }';
        self::_createFile($med,'Interfaces',$med.'RepositoryInterface.php',$contentInterface,'Modules');
    }


    public static function _contentCrudInterface()
    {
        $contentCrudInterface= '<?php
        '.self::_comment().'

namespace App\General\Interfaces;


interface CrudInterface
{
    '.self::_comment().'
    public function getFind($id);
  '.self::_comment().'
    public function getAll();
 '.self::_comment().'
    public function modelDestory($id);


}
        ';
        if (!file_exists('app/General/Interface/CrudInterface.php')) {
            self::_createFile('','Interface','CrudInterface.php',$contentCrudInterface,'General');
        }
    }

}