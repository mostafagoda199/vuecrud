<?php
/**
 * Created by PhpStorm.
 * User: Mustafa
 * Date: 7/26/2019
 * Time: 12:59 AM
 */

namespace App\Console\Commands\Helper;
use App\Console\Commands\Helper\traits\AddComment;
use App\Console\Commands\Helper\traits\CreateFile;
use App\Console\Commands\Helper\traits\EditFile;
use App\Console\Commands\Helper\traits\MoveModel;

class AddProvider
{
    use CreateFile ,AddComment ,MoveModel ,EditFile;
    public static function _contentProvider($med)
    {
        //$if=($this->_moveModels($med))
        $contentProvider='<?php  
'.static::_comment().'
namespace App\Modules\\'.$med.'\Providers;
use App\Modules\\'.$med.'\Models\\'.$med.';
use Illuminate\Support\ServiceProvider;
use App\Modules\\'.$med.'\Repository\\'.$med.'Repository;'.'
use App\Modules\\'.$med.'\Interfaces\\'.$med.'RepositoryInterface;' . '
class ' . $med . 'ServiceProvider extends  ServiceProvider{
public function register()
{
    $model=' . $med . '::class;
    $this->app->singleton(
    ' . $med . 'RepositoryInterface::class, function () use ($model)
       {
            return new '.$med.'Repository(new $model);
          });
       }
}';
        self::_createFile($med,'Providers',$med.'ServiceProvider.php',$contentProvider,'Modules');
    }

    public static function _editProvider($med)
    {
        AddProvider::_contentProvider($med);
        $pathProvider='config/app.php';
        $patternProvider="/ViewServiceProvider::class,/";
        $replacementsProvider="ViewServiceProvider::class,\n \t \t /**New ServicesProvider */ \n \t \t App\Modules\\".$med."\Providers\\".$med."ServiceProvider::class,";
        self::_editFile($pathProvider,$patternProvider,$replacementsProvider);
        dd('Module Created successfully');
    }


}