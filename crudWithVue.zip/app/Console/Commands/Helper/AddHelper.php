<?php
/**
 * Created by PhpStorm.
 * User: Mustafa
 * Date: 7/26/2019
 * Time: 6:30 PM
 */

namespace App\Console\Commands\Helper;
use App\Console\Commands\Helper\traits\AddComment;
use App\Console\Commands\Helper\traits\CreateFile;

class AddHelper
{
    use CreateFile ,AddComment;

    public static function _contentHelper()
    {

$contentHelper= '<?php
        '.self::_comment().'
namespace App\General\Helper;
use Illuminate\Support\Facades\Mail;

class Helper
{
 '.self::_comment().'
    public static function convertSlug($slug)
    {
        return str_replace("--","-",str_replace(" ","-",str_replace("  "," ",trim($slug))));
    }
    
 '.self::_comment().'
    public static function sendMail()
    {
        Mail::send("emails.welcome", [], function($message){
            $message->to("mostafagoda199@gmail.com","mostafagoda199@gmail.com")
                ->subject("Nader el kalb");
            $message->from("mostafagoda199@gmail.com","sas");
        });
    }
}';
        if (!file_exists('app/General/Helper/Helper.php')) {

           // system('');
            static::_createFile('', 'Helper', 'Helper.php', $contentHelper, 'General');
        }
    }
}