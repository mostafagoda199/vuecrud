<?php

namespace App\Console\Commands\Helper;
use App\Console\Commands\Helper\traits\AddComment;
use App\Console\Commands\Helper\traits\CreateFile;

class AddRepository
{
    use CreateFile ,AddComment;
    public static function _contentRepository($med)
    {
        $contentRepository='<?php 
        '.static::_comment().'
        namespace App\Modules\\'.$med.'\Repository;
        use App\Modules\\'.$med.'\Interfaces\\'.$med.'RepositoryInterface;
        use App\General\Helper\Helper;
        use App\General\Repository\CrudRepository;
        use Illuminate\Database\Eloquent\Model;
        use Illuminate\Support\Facades\DB;
        use Illuminate\Support\Facades\Validator;
        class '.$med.'Repository extends CrudRepository implements '.$med.'RepositoryInterface
           {
             protected  $model;
             public function __construct(Model $model)
              {
                  $this->model= $model;
                   parent::__construct($this->model);
              }
        }';

         static::_createFile($med,'Repository',$med.'Repository.php',$contentRepository,'Modules');
    }

    public static function _contentCrudRepository()
    {
        $contentCrudRepository= '<?php
        '.self::_comment().'
namespace App\General\Repository;
use App\General\Interfaces\CrudInterface;
class CrudRepository implements CrudInterface
{
 '.self::_comment().'
    protected $model;
    public function __construct($model)
    {
        $this->model=$model;
    }
 '.self::_comment().'
    public function getAll(){
        return $this->model->all();
    }
 '.self::_comment().'
    public function getFind($id){
        $row=$this->model->where("slug", $id)->first();
        if(isset($row) && !empty($row))
        {
            return $row;
        }
        else
        {
            return abort(404);
        }
    }
 '.self::_comment().'
    public function modelDestory($id){
        $toDelete=$this->getFind($id);
        $this->model->destroy($toDelete->id);
    }
}';
        if (!file_exists('app/General/Repository/CrudRepository.php')) {
            self::_createFile('','Repository','CrudRepository.php',$contentCrudRepository,'General');
        }
    }

}