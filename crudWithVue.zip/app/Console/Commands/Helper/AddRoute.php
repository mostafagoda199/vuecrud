<?php
/**
 * Created by PhpStorm.
 * User: Mustafa
 * Date: 7/26/2019
 * Time: 12:40 AM
 */
namespace App\Console\Commands\Helper;
use App\Console\Commands\Helper\traits\AddComment;
use App\Console\Commands\Helper\traits\CreateFile;
use App\Console\Commands\Helper\traits\EditFile;

class AddRoute
{
    use CreateFile ,AddComment,EditFile;
    public static function _contentRoute($med)
    {
        $contentRoute= "<?php 
        ".static::_comment()."
        Route::group(['middleware' => 'auth'], function () {
        Route::resource('".strtolower($med)."', '".$med."\Controllers\\".$med."Controller');
        });";
        static::_createFile($med,'Route','web.php',$contentRoute,'Modules');
    }


    public static function _editRoute($med)
    {
        $path='app/Providers/RouteServiceProvider.php';
        $re = "/protected function mapSubWebRoutes[^a-zA-Z0-9]*.*\n.*\n.*\n.*/";
        $replacements="protected function mapSubWebRoutes()
        {
        Route::group([
            'middleware' => 'web',
            'namespace' => ".'$'."this->Permission,
        ], function () {
             require base_path('app/Modules/".$med."/Route/web.php');";
        $contents = file_get_contents($path);
        $patern='protected $Permission';
        $escapedUrl = preg_quote($patern, '/');
        $regex = '/' . $escapedUrl.'.*/';
        if(!preg_match_all($regex, $contents, $matches)) {
            $patern='protected $namespace';
            $escapedUrl = preg_quote($patern, '/');
            $regex = '/' . $escapedUrl.'.*/';
            if(preg_match_all($regex, $contents, $matches)) {
                $rep = "protected " . '$' . "namespace = 'App\Http\Controllers';" . "\n" . "\tprotected " . '$' . "Permission = 'App\Modules';";
                self::_editFile($path, $regex, $rep);
            }
        }

        $patern='$this->mapSubWebRoutes';
        $escapedUrl = preg_quote($patern, '/');
        $regex = '/' . $escapedUrl.'.*/';
        if(!preg_match_all($regex, $contents, $matches)) {
            $patern = '$this->mapWebRoutes';
            $escapedUrl = preg_quote($patern, '/');
            $regex = '/' . $escapedUrl . '.*/';
            if (preg_match_all($regex, $contents, $matches)) {
                $rep = '$' . "this->mapWebRoutes();" . "\n" . "\n \t \t" . '$' . "this->mapSubWebRoutes();";
                self::_editFile($path, $regex, $rep);
            }
        }


if(!preg_match_all($re, $contents, $matches)){

    $re1 = "/protected function mapWebRoutes[^a-zA-Z0-9]*.*\n.*\n.*\n.*/";
    $replacement="
      protected function mapWebRoutes()
        {
            Route::middleware('web')
                 ->namespace(".'$'."this->namespace)
                 ->group(base_path('routes/web.php'));
        }
       /**
        * new Route
        */    
            protected function mapSubWebRoutes()
            {
                Route::group([
                    'middleware' => 'web',
                    'namespace' => ".'$'."this->Permission,
                ], function () {
                     require base_path('app/Modules/".$med."/Route/web.php');"."\n"."
                });
            }";
            self::_editFile($path,$re1,$replacement);
        }
else{
    self::_editFile($path,$re,$replacements);
}

    }
}