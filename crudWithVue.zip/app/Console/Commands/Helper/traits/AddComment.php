<?php

namespace App\Console\Commands\Helper\traits;

use Carbon\Carbon;

trait AddComment
{
    private static function _comment()
    {
        return '/**
         * For
         * @author Mustafa Goda <mostafagoda199@gmail.com>
         * @created at '.Carbon::now().'
         * @return 
         */';
    }
}