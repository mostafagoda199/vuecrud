<?php
/**
 * Created by PhpStorm.
 * User: Mustafa
 * Date: 7/26/2019
 * Time: 1:44 AM
 */

namespace App\Console\Commands\Helper\traits;


trait MoveModel
{
    private function _moveModels($med)
    {
        if (file_exists("app/Model/".$med.".php")) {
            copy('app/Model/' . $med . '.php', "app/Modules/" . $med . "/Models/" . $med . ".php");
            $ModelPath='app/Modules/'.$med.'/Models/'.$med.'.php';
            $currentModel = file_get_contents($ModelPath);
            $newModel=str_replace('App\Model','App\Modules\\'.$med.'\Models',$currentModel);
            file_put_contents($ModelPath, $newModel);
            return true;
        }
        else{
            return false;
        }
        echo "Model ".$med."Controller Moved successfully"."\n";
    }
}