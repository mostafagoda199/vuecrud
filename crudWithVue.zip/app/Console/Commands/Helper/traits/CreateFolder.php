<?php
/**
 * Created by PhpStorm.
 * User: Mustafa
 * Date: 7/26/2019
 * Time: 1:07 AM
 */

namespace App\Console\Commands\Helper\traits;


trait CreateFolder
{
    private static function _createFolder($path,$med,$names)
    {
        $med=empty($med) ? '' : '/'.$med;
        if (isset($names) && !empty($names))
        {
            foreach ($names as $name) {
                if (!file_exists($path .$med. '/'  . $name)) {
                    mkdir($path .$med. '/'  . $name, 0755, true);
                    echo $name . "Created successfully" . "\n";
                }
            }
        }

    }
}