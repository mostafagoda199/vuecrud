<?php
/**
 * Created by PhpStorm.
 * User: Mustafa
 * Date: 7/26/2019
 * Time: 12:05 AM
 */
namespace App\Console\Commands\Helper\traits;

trait CreateFile
{
    private static function _createFile($med,$folderName,$fileName,$fileContent,$parentFolder='Modules')
    {
        $content= $fileContent ;
        $file = fopen("app/".$parentFolder.'/'. $med . "/".$folderName."/".$fileName,"w");
        fwrite($file, $content);
        fclose($file);
        echo $fileName." Created successfully"."\n";
    }


}