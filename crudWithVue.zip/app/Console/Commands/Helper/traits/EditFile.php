<?php
/**
 * Created by PhpStorm.
 * User: Mustafa
 * Date: 7/26/2019
 * Time: 1:58 AM
 */

namespace App\Console\Commands\Helper\traits;


trait EditFile
{
    private static function _editFile($path,$pattern,$replacements)
    {
        $current = file_get_contents($path);
        $newController= preg_replace($pattern, $replacements, $current);
        file_put_contents($path, $newController);
    }
}