<?php
/**
 * Created by PhpStorm.
 * User: Mustafa
 * Date: 7/26/2019
 * Time: 12:23 AM
 */

namespace App\Console\Commands\Helper;
use App\Console\Commands\Helper\traits\AddComment;
use App\Console\Commands\Helper\traits\CreateFile;

class AddView
{
    use CreateFile ,AddComment;
    public static function _contentView($med,$views)
    {
        $contentView= "@extends('layouts.master')
        @section('content')
        @endsection";
        foreach ($views as $view){
            static::_createFile($med,'views',$view.'.blade.php',$contentView,'Modules');
        }
    }
}