<?php
/**
 * For
 * @author Mustafa Goda <mostafagoda199@gmail.com>
 * @created at 2019-08-05 11:47:44
 * @return
 */

namespace App\General\Helper;

use Illuminate\Support\Facades\Mail;

class Helper
{
    /**
     * For
     * @author Mustafa Goda <mostafagoda199@gmail.com>
     * @created at 2019-08-05 11:47:44
     * @return
     */
    public static function convertSlug($slug)
    {
        return str_replace("--", "-", str_replace(" ", "-", str_replace("  ", " ", trim($slug))));
    }

    /**
     * For
     * @author Mustafa Goda <mostafagoda199@gmail.com>
     * @created at 2019-08-05 11:47:44
     * @return
     */
    public static function sendMail()
    {
        Mail::send("emails.welcome", [], function ($message) {
            $message->to("mostafagoda199@gmail.com", "mostafagoda199@gmail.com")
                ->subject("Nader el kalb");
            $message->from("mostafagoda199@gmail.com", "sas");
        });
    }
}