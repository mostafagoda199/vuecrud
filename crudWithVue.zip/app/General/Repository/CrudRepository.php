<?php
/**
 * For
 * @author Mustafa Goda <mostafagoda199@gmail.com>
 * @created at 2019-08-05 11:47:44
 * @return
 */

namespace App\General\Repository;

use App\General\Interfaces\CrudInterface;

class CrudRepository implements CrudInterface
{
    /**
     * For
     * @author Mustafa Goda <mostafagoda199@gmail.com>
     * @created at 2019-08-05 11:47:44
     * @return
     */
    protected $model;

    public function __construct($model)
    {
        $this->model = $model;
    }

    /**
     * For
     * @author Mustafa Goda <mostafagoda199@gmail.com>
     * @created at 2019-08-05 11:47:44
     * @return
     */
    public function getAll()
    {
        return $this->model->all();
    }

    /**
     * For
     * @author Mustafa Goda <mostafagoda199@gmail.com>
     * @created at 2019-08-05 11:47:44
     * @return
     */
    public function getFind($id)
    {
        $row = $this->model->where('id', $id)->first();
        return $row;
    }

    /**
     * For
     * @author Mustafa Goda <mostafagoda199@gmail.com>
     * @created at 2019-08-05 11:47:44
     * @return
     */

}