<?php
/**
 * For
 * @author Mustafa Goda <mostafagoda199@gmail.com>
 * @created at 2019-08-05 11:47:44
 * @return
 */

namespace App\General\Interfaces;


interface CrudInterface
{
    /**
     * For
     * @author Mustafa Goda <mostafagoda199@gmail.com>
     * @created at 2019-08-05 11:47:44
     * @return
     */
    public function getFind($id);

    /**
     * For
     * @author Mustafa Goda <mostafagoda199@gmail.com>
     * @created at 2019-08-05 11:47:44
     * @return
     */
    public function getAll();



}
        