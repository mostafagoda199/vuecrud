<?php             
        /**
         * For
         * @author Mustafa Goda <mostafagoda199@gmail.com>
         * @created at 2019-08-05 11:50:15
         * @return 
         */
        namespace App\Modules\Product\Interfaces; 
        interface ProductRepositoryInterface{
            public function storeProduct($data);

            public function updateProduct($id,$data);

            public function modelDestory($id);

            public function imgDestory($id);


        }