<?php 
        /**
         * For
         * @author Mustafa Goda <mostafagoda199@gmail.com>
         * @created at 2019-08-05 11:50:15
         * @return 
         */
        namespace App\Modules\Product\Repository;
        use App\Modules\Product\Interfaces\ProductRepositoryInterface;
        use App\General\Helper\Helper;
        use App\General\Repository\CrudRepository;
        use App\Modules\Product\Models\ProductImage;
        use Illuminate\Database\Eloquent\Model;
        use Illuminate\Support\Facades\DB;
        use Illuminate\Support\Facades\Validator;
        class ProductRepository extends CrudRepository implements ProductRepositoryInterface
           {
             protected  $model;
             public function __construct(Model $model)
              {
                  $this->model= $model;
                   parent::__construct($this->model);
              }


            public function storeProduct($data)
            {
                $this->model->name=$data['name'];
                $this->model->category_id=$data['category_id'];
                $this->model->price=$data['price'];
                $this->model->slug=Helper::convertSlug($data['name']);
                $this->model->save();
                if ($data->hasFile('img')) {
                    $files = $data->file('img');
                    foreach($files as $file) {
                        $name = Helper::convertSlug($data['name']) . '_' . time() . '-crud.com.' . $file->getClientOriginalExtension();
                        $path = public_path('/');
                        $file->move($path, $name);
                        $addimg = new ProductImage();
                        $addimg->img = $data['img'];
                        $addimg->product_id = $this->model->id;
                        $addimg->alt = $data['alt'];
                        $addimg->save();
                    }
                }
            }


            public function updateProduct($id,$data)
            {
                $product=$this->getFind($id);
                $product->name=$data['name'];
                $product->category_id=$data['category_id'];
                $product->price=$data['price'];
                $product->slug=Helper::convertSlug($data['name']);
                $product->save();
                if ($data->hasFile('img')) {
                    $files = $data->file('img');
                    foreach($files as $file) {
                        $name = Helper::convertSlug($data['name']) . '_' . time() . '-crud.com.' . $file->getClientOriginalExtension();
                        $path = public_path('/');
                        $file->move($path, $name);
                        $addimg = new ProductImage();
                        $addimg->img = $data['img'];
                        $addimg->product_id = $product->id;
                        $addimg->alt = $data['alt'];
                        $addimg->save();
                    }
                }

            }

            public function modelDestory($id)
            {
                $toDelete = $this->getFind($id);
                $productImages = $this->getFind($id)->images()->get();
                if (isset($productImages))
                {
                    foreach ($productImages as $productImage)
                    {
                        $this->imgDestory($productImage->id);
                    }
                }
                $this->model->destroy($toDelete->id);

            }

            public function imgDestory($id)
            {
                ProductImage::destroy($id);
            }


        }