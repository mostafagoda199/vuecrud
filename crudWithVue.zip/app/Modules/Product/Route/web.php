<?php
/**
 * For
 * @author Mustafa Goda <mostafagoda199@gmail.com>
 * @created at 2019-08-05 11:50:15
 * @return
 */
Route::resource('product', 'Product\Controllers\ProductController');
