<?php
namespace App\Modules\Product\Models;
use Illuminate\Database\Eloquent\Model;
class ProductImage extends Model
{
    protected $table="product_images";
    protected $fillable=['img', 'product_id', 'alt',];
    /**
     * For
     * @author Mustafa Goda <mostafagoda199@gmail.com>
     * @created at 2019-08-05 11:47:44
     * @return
     */
    public function product()
    {
        return $this->belongsTo('App\Modules\Product\Models\Product','product_id');
    }
}
