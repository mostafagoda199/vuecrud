<?php

namespace App\Modules\Product\Models;

use Illuminate\Database\Eloquent\Model;

class Product extends Model
{
    protected $table="products";
    protected $fillable=['category_id', 'name', 'slug',];

    /**
     * For
     * @author Mustafa Goda <mostafagoda199@gmail.com>
     * @created at 2019-08-05 11:47:44
     * @return
     */
    public function category()
    {
        return $this->belongsTo('App\Modules\Category\Models\Category','category_id');
    }
    public function images()
    {
        return $this->hasMany('App\Modules\Product\Models\ProductImage','product_id', 'id');
    }
}
