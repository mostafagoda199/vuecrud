<?php

namespace App\Modules\Product\controllers;

use App\Modules\Category\Interfaces\CategoryRepositoryInterface;
use App\Modules\Product\Interfaces\ProductRepositoryInterface;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class ProductController extends Controller
{
    protected $aCategory;
    protected $aProduct;
    public function __construct(CategoryRepositoryInterface $category,ProductRepositoryInterface $product)
    {
        $this->aCategory=$category;
        $this->aProduct=$product;
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $cat=[];
        $category = $this->aCategory->getAll();
        foreach ($category as $i => $categorys) {
            $cat[$i] = ['id' => $categorys->id, 'name' => $categorys->name];
            $products = $this->aCategory->getFind($categorys->id)->products()->get(['id', 'name','price']);
            if (isset($products) && !empty($products))
            {
                foreach ($products as $p => $product) {
                    $cat[$i]['prodcts'][$p]=['id'=>$product->id,'name'=>$product->name];
                    $productimgs = $this->aProduct->getFind($product->id)->images()->get('img');
                    $cat[$i]['prodcts'][$p]['images']=[];
                    if (isset($productimgs) && !empty($productimgs))
                    {
                        foreach ($productimgs as $img => $productimg)
                        {
                            $cat[$i]['prodcts'][$p]['images'][$img]=$productimg->img;
                        }
                    }
                }
            }
        }
        return response()->json($cat);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $this->aProduct->storeProduct($request->all());
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $product = $this->aProduct->getFind($id);
        $cat= $this->aCategory->getFind($product->category_id);
        $prod=['id'=>$product->id,'name'=>$product->name ,'cat_name'=>$cat->name];
        $productimgs = $this->aProduct->getFind($id)->images()->get('img');
        foreach ($productimgs as $i=>$productimg)
        {
            $prod['images'][$i]=$productimg->img;
        }
        return response()->json($prod);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $this->aProduct->updateProduct($id,$request->all());
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $this->aProduct->modelDestory($id);
    }
}
