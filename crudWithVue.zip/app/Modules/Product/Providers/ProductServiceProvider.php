<?php  
/**
         * For
         * @author Mustafa Goda <mostafagoda199@gmail.com>
         * @created at 2019-08-05 11:50:15
         * @return 
         */
namespace App\Modules\Product\Providers;
use App\Modules\Product\Models\Product;
use Illuminate\Support\ServiceProvider;
use App\Modules\Product\Repository\ProductRepository;
use App\Modules\Product\Interfaces\ProductRepositoryInterface;
class ProductServiceProvider extends  ServiceProvider{
public function register()
{
    $model=Product::class;
    $this->app->singleton(
    ProductRepositoryInterface::class, function () use ($model)
       {
            return new ProductRepository(new $model);
          });
       }
}