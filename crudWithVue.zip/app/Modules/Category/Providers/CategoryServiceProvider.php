<?php  
/**
         * For
         * @author Mustafa Goda <mostafagoda199@gmail.com>
         * @created at 2019-08-05 11:47:44
         * @return 
         */
namespace App\Modules\Category\Providers;
use App\Modules\Category\Models\Category;
use Illuminate\Support\ServiceProvider;
use App\Modules\Category\Repository\CategoryRepository;
use App\Modules\Category\Interfaces\CategoryRepositoryInterface;
class CategoryServiceProvider extends  ServiceProvider{
public function register()
{
    $model=Category::class;
    $this->app->singleton(
    CategoryRepositoryInterface::class, function () use ($model)
       {
            return new CategoryRepository(new $model);
          });
       }
}