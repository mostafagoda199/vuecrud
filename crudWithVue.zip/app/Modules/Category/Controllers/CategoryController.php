<?php

namespace App\Modules\Category\controllers;

use App\Modules\Category\Interfaces\CategoryRepositoryInterface;
use App\Modules\Product\Interfaces\ProductRepositoryInterface;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class CategoryController extends Controller
{
    protected $aCategory;
    protected $aProduct;
    public function __construct(CategoryRepositoryInterface $category,ProductRepositoryInterface $product)
    {
        $this->aCategory=$category;
        $this->aProduct=$product;
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $cat=[];
        $category = $this->aCategory->getAll();
        foreach ($category as $i => $categorys) {
            $cat[$i] = ['id' => $categorys->id, 'name' => $categorys->name];
            $products = $this->aCategory->getFind($categorys->id)->products()->get(['id', 'name','price']);
            if (isset($products) && !empty($products))
            {
                foreach ($products as $p => $product) {
                    $cat[$i]['prodcts'][$p]=['id'=>$product->id,'name'=>$product->name];
                    $productimgs = $this->aProduct->getFind($product->id)->images()->get('img');
                    $cat[$i]['prodcts'][$p]['images']=[];
                    if (isset($productimgs) && !empty($productimgs))
                    {
                        foreach ($productimgs as $img => $productimg)
                        {
                            $cat[$i]['prodcts'][$p]['images'][$img]=$productimg->img;
                        }
                    }
                }
            }
        }
        return response()->json($cat);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {

    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $this->aCategory->storeCategory($request->all());
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
       $categor=[];
       $cat= $this->aCategory->getFind($id);
       $categor=['id'=>$cat->id,'name'=>$cat->name];
       $products = $this->aCategory->getFind($id)->products()->get(['id', 'name','price']);
        if (isset($products) && !empty($products))
        {
            foreach ($products as $p => $product) {
                $categor['prodcts'][$p]=['id'=>$product->id,'name'=>$product->name];
                $productimgs = $this->aProduct->getFind($product->id)->images()->get('img');
                $categor['prodcts'][$p]['images']=[];
                if (isset($productimgs) && !empty($productimgs))
                {
                    foreach ($productimgs as $img => $productimg)
                    {
                        $categor['prodcts'][$p]['images'][$img]=$productimg->img;
                    }
                }
            }
        }
        return response()->json($categor);

    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $this->aCategory->updateCategory($id,$request->all());
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $this->aCategory->modelDestory($id);
    }
}
