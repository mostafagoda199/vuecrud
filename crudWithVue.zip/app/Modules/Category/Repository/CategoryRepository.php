<?php
/**
 * For
 * @author Mustafa Goda <mostafagoda199@gmail.com>
 * @created at 2019-08-05 11:47:44
 * @return
 */

namespace App\Modules\Category\Repository;

use App\Modules\Category\Interfaces\CategoryRepositoryInterface;
use App\General\Helper\Helper;
use App\General\Repository\CrudRepository;
use App\Modules\Product\Interfaces\ProductRepositoryInterface;
use App\Modules\Product\Repository\ProductRepository;
use Illuminate\Database\Eloquent\Model;
class CategoryRepository extends CrudRepository implements CategoryRepositoryInterface
{
    protected $model;
   // protected $product;

    public function __construct(Model $model)//
    {
       // ,ProductRepositoryInterface $product
       //$this->product = new ProductRepository();
        $this->model = $model;
        parent::__construct($this->model);
    }

    public function storeCategory($data)
    {
        $this->model->name=$data['name'];
        $this->model->slug=Helper::convertSlug($data['name']);
        $this->model->save();
    }


    public function updateCategory($id,$data)
    {
        $category=$this->getFind($id);
        $category->name=$data['name'];
        $category->slug=Helper::convertSlug($data['name']);
        $category->save();
    }

    public function modelDestory($id)
    {

   /*     $toDelete = $this->getFind($id);
        $products = $this->getFind($id)->products()->get();
        if (isset($products))
        {
            foreach ($products as $product)
            {
                $producta= new ProductRepository($this->model);
                $producta->modelDestory($product->id);
              //  $this->product->modelDestory($product->slug);
            }
        }*/
        $this->model->destroy($id);
    }
}