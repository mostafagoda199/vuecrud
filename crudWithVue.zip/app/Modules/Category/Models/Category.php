<?php

namespace App\Modules\Category\Models;

use Illuminate\Database\Eloquent\Model;

class Category extends Model
{
    protected $table="categories";
    protected $fillable=['name', 'slug',];
    /**
     * For
     * @author Mustafa Goda <mostafagoda199@gmail.com>
     * @created at 2019-08-05 11:47:44
     * @return
     */
    public function products()
    {
        return $this->hasMany('App\Modules\Product\Models\Product','category_id', 'id');
    }
}
