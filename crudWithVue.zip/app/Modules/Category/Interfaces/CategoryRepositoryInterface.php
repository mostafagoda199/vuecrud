<?php
/**
 * For
 * @author Mustafa Goda <mostafagoda199@gmail.com>
 * @created at 2019-08-05 11:47:44
 * @return
 */

namespace App\Modules\Category\Interfaces;
interface CategoryRepositoryInterface
{
    public function storeCategory($data);

    public function updateCategory($id,$data);

    public function modelDestory($id);
}