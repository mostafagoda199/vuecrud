&lt;h1&gt;Welcome To Our App&lt;/h1&gt;
&lt;p&gt;You are welcome to our platform.&lt;/p&gt;