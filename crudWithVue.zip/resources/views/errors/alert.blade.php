<script src="https://cdn.jsdelivr.net/npm/sweetalert2@8"></script>
@if(Session::has('success'))

    <script>
        Swal.fire({
            position: 'center',
            type: 'success',
            title: "{{Session::get('success')}}",
            showConfirmButton: false,
            timer: 2000
        });
    </script>

@elseif(Session::has('error'))
    <script>
        Swal.fire({
            position: 'center',
            type: 'error',
            title: "{{Session::get('error')}}",
            showConfirmButton: false,
            timer: 2000
        });
    </script>
@endif




{{--
@if(Session::has('success'))
 <script>
     swal("تنبية!", "{{Session::get('success')}}!", "success");
 </script>
 @elseif(Session::has('error'))
 <script>
     swal("تنبية!", "{{Session::get('error')}}!", "error");
 </script>
 @endif--}}
