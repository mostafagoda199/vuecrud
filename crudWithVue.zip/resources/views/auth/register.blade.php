@extends('layouts.app')

@section('content')
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-12">
                <form class="md-float-material form-material" method="POST" action="{{ route('register') }}" aria-label="{{ __('register') }}" enctype="multipart/form-data">
                    @csrf
                    <div class="auth-box card">
                        <div class="card-block">
                            <div class="row m-b-20">
                                <div class="col-md-12 text-center">
                                    <img src="{{asset('public/asset/')}}/files/assets/images/Labs.png" alt="" style="height: 80px;">
                                    <h3 class="text-center txt-primary"> ادخل الى لوحة تحكم </h3>
                                </div>
                            </div>
                            <div class="form-group form-primary">
                                <input type="text"  class="form-control" required="required" class="form-control{{ $errors->has('name') ? ' is-invalid' : '' }}" name="name" placeholder="{{ __('الاسم') }}">
                                <span class="form-bar"></span>
                            </div>

                     {{--       <div class="form-group form-primary">
                                <input type="text"  class="form-control" required="" class="form-control{{ $errors->has('name') ? ' is-invalid' : '' }}" name="name" placeholder="{{ __('اسم مدير المعمل') }}">
                                <span class="form-bar"></span>
                            </div>--}}
                            <!--  -->
                            <div class="form-group form-primary">
                                <input type="text" id="phone" type="phone" class="form-control{{ $errors->has('phone') ? ' is-invalid' : '' }}" name="phone" placeholder="{{ __('رقم الهاتف ') }}">
                                <span class="form-bar"></span>
                            </div>
                            <div class="form-group form-primary">
                                <input type="text" id="email" type="email" class="form-control{{ $errors->has('email') ? ' is-invalid' : '' }}" name="email"  required autofocus placeholder="{{ __('البريد الالكتروني') }} ">
                                <span class="form-bar"></span>
                            </div>

                            <div class="row">
                                <div class="col-sm-6">
                                    <div class="form-group form-primary">
                                        <input type="password" name="password" class="form-control" required="" placeholder="{{ __('الرقم السري') }}">
                                        <span class="form-bar"></span>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="form-group form-primary">
                                        <input type="password" name="confirm-password" class="form-control" required="" placeholder="{{ __('تاكيد الرقم السري') }}">
                                        <span class="form-bar"></span>
                                    </div>
                                </div>
                            </div>
                    {{--        <div class="row">
                                <div class="col-sm-12">
                                    <div class=" form-group form-primary">
                                        @if(isset($packages) && !empty($packages))
                                            <select class="col-sm-12" style="font-size: 19px;" name="package">
                                                @foreach($packages as $package)
                                                    <option value="{{$package->id}}" >{{$package->name}}</option>
                                                @endforeach
                                            </select>
                                        @endif

                                        <span class="form-bar"></span>
                                    </div>
                                </div>
                            </div>--}}

                        {{--    <div style="float: right;" class="row m-t-30 text-left">
                                <div class="col-md-9">
                                    <input  id="img" type="file"  name="img">
                                    @if ($errors->has('img'))
                                        <span class="invalid-feedback" role="alert">
                                                <strong>{{ $errors->first('img') }}</strong>
                                             </span>
                                    @endif
                                </div>
                            </div>--}}

                    {{--        <div class="input-group">
                                <div class="input-group-prepend">
                                    <span class="input-group-text" id="inputGroupFileAddon01">اضف لوجو الموقع  </span>
                                </div>
                                <div class="custom-file">
                                    <input type="file" class="custom-file-input" name="file" id="inputGroupFile01"
                                           aria-describedby="inputGroupFileAddon01">
                                <label class="custom-file-label" for="inputGroupFile01"><i class="ti-gallery"></i></label>
                                </div>
                            </div>--}}


                            <div class="row m-t-30">
                                <div class="col-md-12">
                                    <button type="submit" class="btn btn-primary btn-md btn-block waves-effect text-center m-b-20">{{ __('انشاء حساب') }}</button>
                                </div>
                            </div>
                            <hr>
                            <div class="row m-t-25 text-left">
                                <div class="col-12">
                                    <div class="forgot-phone text-center">
                                        <a href="{{ route('login') }}" class="text-right f-w-600"> {{ __('انت مسجل بالفعل') }}</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
            <!-- end of col-sm-12 -->
        </div>
        <!-- end of row -->
    </div>

@endsection
