@extends('layouts.app')

@section('content')
    <!-- Container-fluid starts -->
    <div class="container">
        <div class="row">
            <div class="col-sm-12">
                <!-- Authentication card start -->

                <form class="md-float-material form-material" method="POST" action="{{ route('login') }}" aria-label="{{ __('Login') }}">
                    @csrf

                    <div class="text-center">
                        <img src="{{asset('public/asset/')}}/files/assets/images/Labs.png" alt="logo.png" style="height: 100px;">
                    </div>
                    <div class="auth-box card">
                        <div class="card-block">
                            <div class="row m-b-20">
                                <div class="col-md-12">
                                    <h3 class="text-center">تسجيل الدخول</h3>
                                </div>
                            </div>
                            <div class="form-group form-primary">
                                <input type="text" name="email" class="form-control" required="" placeholder="{{ __('البريد الالكتروني') }}">
                                <span class="form-bar"></span>
                                @if ($errors->has('email'))
                                    <span class="invalid-feedback " role="alert">
                                      {{ $errors->first('email') }}
                                    </span>
                                @endif
                            </div>
                            <div class="form-group form-primary">
                                <input type="password" name="password" class="form-control{{ $errors->has('password') ? ' is-invalid' : '' }}" name="password" required placeholder="{{ __('الرقم السري') }}">
                                <span class="form-bar"></span>
                                @if ($errors->has('password'))
                                    <span class="invalid-feedback" role="alert">
                                        {{ $errors->first('password') }}
                                    </span>
                                @endif
                            </div>

                            <div class="row m-t-25 text-left">
                                <div class="col-12">
                                    <div class="checkbox-fade fade-in-primary">
                                        <label>
                                            <input type="checkbox"  name="remember" {{ old('remember') ? 'checked' : '' }} id="customCheck1">
                                            <span class="cr"><i class="cr-icon icofont icofont-ui-check txt-primary"></i></span>
                                            <span class="text-inverse">تذكرني </span>
                                        </label>
                                    </div>
                                    <div class="forgot-phone text-right f-right">
                                        <a href="{{ route('password.request') }}" class="text-right f-w-600"> {{ __('نسيت كلمة المرور') }}</a>
                                    </div>
                                </div>
                            </div>
                            <div class="row m-t-30">
                                <div class="col-md-12">
                                    <button type="submit" class="btn btn-primary btn-md btn-block waves-effect waves-light text-center m-b-20"> {{ __('دخول') }}</button>
                                </div>
                            </div>
                            <hr>
                            <div class="row m-t-25 text-left">
                                <div class="col-12">
                                    <div class="forgot-phone text-center">
                                        <a href="{{ route('register') }}" class="text-right f-w-600"> {{ __('سجل معنا') }}</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
                <!-- end of form -->
            </div>
            <!-- end of col-sm-12 -->
        </div>
        <!-- end of row -->
    </div>
    <!-- end of container-fluid -->

@endsection
