import Vue from 'vue';
import VueRouter from 'vue-router';
import VueAxios from 'vue-axios';
import axios from 'axios';
import App from './App.vue';
import CreateCategory from './components/category/CreateCategory.vue';
import DisplayCategory from './components/category/DisplayCategory.vue';
import EditCategory from './components/category/EditCategory.vue';

import CreateProduct from './components/product/CreateProduct.vue';
import DisplayProduct from './components/product/DisplayProduct.vue';
import EditProduct from './components/product/EditProduct.vue';


Vue.use(VueRouter);
Vue.use(VueAxios, axios);
const routes = [
    {
        name: 'CreateCategory',
        path: '/category/create',
        component: CreateCategory
    },
    {
        name: 'DisplayCategory',
        path: '/category',
        component: DisplayCategory
    },
    {
        name: 'EditCategory',
        path: '/category/edit/:id',
        component: EditCategory
    } ,
    {
        name: 'CreateProduct',
        path: '/product/create',
        component: CreateProduct
    },
    {
        name: 'DisplayProduct',
        path: '/product/',
        component: CreateProduct
    },
    {
        name: 'EditProduct',
        path: '/product/',
        component: EditProduct
    }
];

const router = new VueRouter({mode: 'history', routes: routes});
new Vue(Vue.util.extend({router}, App)).$mount('#app');
